
This data download contains two data files. The file named “filtered_” 
includes the data for the countries and periods you selected. The file 
named “all_” contains all of the data covered by the OECD Going Digital 
Toolkit for this indicator or set of indicators if you downloaded the 
data from one of the country dashboards.

Some data download files include the variable “Type” = “distance”. 
Distance refers to the scores presented in the Indicator overview and 
Progress over time dashboard. These scores express each country value as 
a proportion of the best performing country value, which is set equal to 
100. To calculate scores for all countries and variables in each period, 
missing observations are substituted with observations carried-forward 
from the most recent of the preceding three periods (i.e. n-1, n-2 or n-3), 
depending on availability.

Several different time variables are used across the Toolkit databases:
“Year” is used to denote a specific year to which the value relates.
“Time” indicates the point in time to which the value relates. Most often 
this is a specific year, but if the value relates to a multi-year period 
(as indicated by "Period"), then "Time" takes the last year in the period.
"Period” also indicates the time to which a value relates. This may be a 
multi-year period (e.g. 2014-2017), but in most cases it relates to a 
specific year (and so equals “Time” or “Year”).
“Time_data” is used to indicate when carry-forward has taken place 
(see above). In those cases, “Time_data” < “Time”.

Not all data download files contain every one of these time variables.

If you have any comments or questions, please contact 
goingdigitaltoolkit@oecd.org.

Thank you for using the OECD Going Digital Toolkit.

https://www.oecd.org/going-digital-toolkit

Date of retrieval
=================
9/22/2021